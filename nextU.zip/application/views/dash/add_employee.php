<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(!$_SESSION['u_name']){
    redirect('home','refresh');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<!---navbar--->
<?php $this->load->view('dash/inc/nav');?>    
<!---End navbar--->

<section>
    <div class="container py-3">
        <div class="row">
            <div class="col-md-3 col-lg-3 col-sm-3">
                <!---sidebar--->
                <?php $this->load->view('dash/inc/sidebar');?>
                <!---End sidebar--->
            </div>
            <div class="col-md-9 col-lg-9 col-sm-9">
                <h1>Add Employee Screen</h1>
                <hr/>
                <?php echo form_open('employees/add_employee_process');?>
                    <div class="mb-3">
                        <label class="form-label">Employee Name</label>
                        <input type="text" class="form-control" placeholder="Enter Employee Name..." name="e_name">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email ID</label>
                        <input type="text" class="form-control" placeholder="Enter Employee Email ID..." name="e_email">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Mobile No.</label>
                        <input type="text" class="form-control" placeholder="Enter Phone no...." name="e_phone">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Employee Job</label>
                        <select name="e_job" class="form-select">
                            <option selected value="_">-</option>
                            <?php
                            $job_list = $this->db->get('jobs');
                            foreach($job_list->result() as $jobs)
                            { ?>
                                <option value="<?php echo $jobs->j_name;?>"><?php echo $jobs->j_name;?></option>
                            <?php }

                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <input type="submit" class="btn btn-dark" value="Add Employee" name="add_employee">
                    </div>
                <?php echo form_close();?>
            </div>
        </div>
    </div>
</section>



    <script src="<?php echo base_url();?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url();?>assets/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
</body>
</html>