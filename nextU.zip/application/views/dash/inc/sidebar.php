<div class="list-group shadow rounded">
    <a href="#" class="list-group-item list-group-item-action bg-warning" aria-current="true">
        Employee Details
    </a>
    <a href="<?php echo site_url();?>employees/add_employee" class="list-group-item list-group-item-action">Add Employee</a>
    <a href="<?php echo site_url();?>employees" class="list-group-item list-group-item-action">List of Employees</a>
</div>
<hr/>
<div class="list-group shadow rounded">
    <a href="#" class="list-group-item list-group-item-action bg-success text-white" aria-current="true">
        Job Details
    </a>
    <a href="<?php echo site_url();?>jobs/" class="list-group-item list-group-item-action">Add Job</a>
    <a href="<?php echo site_url();?>jobs/view_jobs" class="list-group-item list-group-item-action">List of Jobs</a>
</div>