<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(!$_SESSION['u_name']){
    redirect('home','refresh');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<!---navbar--->
<?php $this->load->view('dash/inc/nav');?>    
<!---End navbar--->

<section>
    <div class="container py-3">
        <div class="row">
            <div class="col-md-3 col-lg-3 col-sm-3">
                <!---sidebar--->
                <?php $this->load->view('dash/inc/sidebar');?>
                <!---End sidebar--->
            </div>
            <div class="col-md-9 col-lg-9 col-sm-9">
                <h1>Job Details</h1>
                <hr/>
                <table class="table table-bordered">
                    <tr class="table-dark table-bordered-text-light text-center">
                        <th>#</th>
                        <th>Job_Name</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    <?php
                    
                    $job_list=$this->db->get('jobs');
                    foreach ($job_list->result() as $job )
                    { ?>
                        <tr>
                            <td class="text-center"><?php echo $job->j_id;?></td>
                            <td><?php echo $job->j_name;?></td>
                            <td class="text-center"><a href="<?php echo site_url();?>Jobs/update_job/<?php echo $job->j_id;?>" class="btn btn-success btn-block btn-sm text-center">Edit</a></td>
                            <td class="text-center"><a href="<?php echo site_url();?>Jobs/delete_job/<?php echo $job->j_id;?>" class="btn btn-danger btn-block btn-sm text-center">Delete</a></td>
                        </tr>
                    <?php }
                    ?>
                </table>
            </div>
        </div>
    </div>
</section>



    <script src="<?php echo base_url();?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url();?>assets/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
</body>
</html>