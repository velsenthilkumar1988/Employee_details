<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(!$_SESSION['u_name']){
    redirect('home','refresh');
}
$id = $this->uri->segment(3);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<!---navbar--->
<?php $this->load->view('dash/inc/nav');?>    
<!---End navbar--->

<section>
    <div class="container py-3">
        <div class="row">
            <div class="col-md-3 col-lg-3 col-sm-3">
                <!---sidebar--->
                <?php $this->load->view('dash/inc/sidebar');?>
                <!---End sidebar--->
            </div>
            <div class="col-md-9 col-lg-9 col-sm-9 table-responsive">
                <h1>Job Details</h1>
                <hr/>
                <table class="table table-bordered">
                    <?php 
                        $employee_details = $this->db->get_where('employees',array('e_id' => $id));
                        foreach($employee_details->result() as $employ)
                        {?>
                            <tr>
                                <th class="bg-dark text-light" style="text-align: right;">Employee ID</th>
                                <td style="width: 70%" class="bg-warning shadow"><?php echo $employ->e_id; ?></td>
                            </tr>

                            <tr>
                                <th class="bg-dark text-light" style="text-align: right;">Employee Date / Time / Hr</th>
                                <td style="width: 70%" class="bg-success shadow text-light"><?php echo $employ->e_date; ?></td>
                            </tr>

                            <tr>
                                <th class="bg-dark text-light" style="text-align: right;">Employee Name</th>
                                <td style="width: 70%" class="bg-warning shadow"><?php echo $employ->e_name; ?></td>
                            </tr>

                            <tr>
                                <th class="bg-dark text-light" style="text-align: right;">Email ID</th>
                                <td style="width: 70%" class="bg-success shadow text-light"><?php echo $employ->e_email; ?></td>
                            </tr>

                            <tr>
                                <th class="bg-dark text-light" style="text-align: right;">Mobile no.</th>
                                <td style="width: 70%" class="bg-warning shadow"><?php echo $employ->e_phone; ?></td>
                            </tr>

                            <tr>
                                <th class="bg-dark text-light" style="text-align: right;">Employee Job.</th>
                                <td style="width: 70%" class="bg-success shadow text-light"><?php echo $employ->e_job; ?></td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="<?php echo site_url();?>employees/update_employee/<?php echo $employ->e_id;?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="<?php echo site_url();?>employees/delete_employee/<?php echo $employ->e_id;?>" class="btn btn-danger btn-sm">Delete</a>
                                </td>
                            </tr>
                        <?php }
                    ?>
                    
                </table>
            </div>
        </div>
    </div>
</section>



    <script src="<?php echo base_url();?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url();?>assets/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
</body>
</html>