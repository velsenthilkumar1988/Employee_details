<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<section class="text-bg-dark p-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 py-3">
            </div>
            <div class="shadow-lg col-lg-4 col-md-4 py-3 bg-body-tertiary">
                <?php echo form_open('home/register_process');?>
                    <div class="text-center bg-default shadow-lg">
                        <img class="bg-default" src="<?php echo base_url();?>assets/images/draw2.webp" width="100%" height="200" style=""/>
                        <h3 class="text-dark fw-bold p-2">Next-U Job Consultancy</h3>
                    </div>    

                    <div class="shadow-lg p-3 mb-5 bg-body-tertiary rounded">
                    <h5 class="text-dark p-1 fw-bold text-center">NEW REGISTRATION</h5>
                        <div class="mb-3">
                            <label class="form-label text-dark">Email ID :</label>
                            <input type="email" class="form-control"  placeholder="Enter email ID eg:john@name.com" name="u_email">
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-dark">User Name :</label>
                            <input type="text" class="form-control"  placeholder="Enter Username eg:john" name="u_name">
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-dark">Password</label>
                            <input type="password" class="form-control" placeholder="Enter Password eg:john@123" name="u_pass">
                        </div>
                        <input type="submit" name="u_register" class="btn btn-success bg-success text-light p-2" value="REGISTER">    
                        <a href="<?php echo base_url();?>" class="btn btn-primary p-2">Back to Home</a>   
                        <hr/> 
                        <p class="text-center bg-dark text-light p-2"><a href="#" class="text-light link-dark link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">2023@copyright | NEXT-U Consultancy Services </a></p>
                    </div>
                    <?php echo form_close();?>    
            </div>
        </div>
    </div>
</section>